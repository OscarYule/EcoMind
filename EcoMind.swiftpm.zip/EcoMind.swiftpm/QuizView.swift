//
//  QuizView.swift
//  EcoMind
//
//  Created by Xavier Yan on 11/20/23.
//

import Foundation
import SwiftUI


struct QuizQuestion: Identifiable {
    let id = UUID()
    let question: String
    let options: [String]
    let correctAnswer: String
}

let allQuizQuestions = [
    QuizQuestion(question: "What is the main greenhouse gas responsible for global warming?", options: ["Carbon Dioxide", "Oxygen", "Helium", "Nitrogen"], correctAnswer: "Carbon Dioxide"),
    QuizQuestion(question: "Which renewable energy source derives power from the Sun?", options: ["Solar Energy", "Wind Energy", "Hydropower", "Biomass"], correctAnswer: "Solar Energy"),
    QuizQuestion(question: "What is the process of converting waste into new material?", options: ["Recycling", "Incineration", "Landfill", "Composting"], correctAnswer: "Recycling"),
    QuizQuestion(question: "Which layer of the atmosphere is damaged by CFCs?", options: ["Stratosphere", "Troposphere", "Mesosphere", "Exosphere"], correctAnswer: "Stratosphere"),
    QuizQuestion(question: "What percentage of Earth's water is freshwater?", options: ["3%", "23%", "47%", "70%"], correctAnswer: "3%"),
    QuizQuestion(question: "Deforestation majorly impacts the habitat of which animal?", options: ["Polar Bears", "Orangutans", "Penguins", "Camels"], correctAnswer: "Orangutans"),
    QuizQuestion(question: "What type of energy is produced by moving water?", options: ["Hydropower", "Solar Power", "Wind Power", "Geothermal Energy"], correctAnswer: "Hydropower"),
    QuizQuestion(question: "What is a major consequence of ozone layer depletion?", options: ["Global Warming", "Increased Air Pollution", "Acid Rain", "Increased UV Radiation"], correctAnswer: "Increased UV Radiation"),
    QuizQuestion(question: "Which activity contributes most to carbon footprint?", options: ["Air Travel", "Cycling", "Recycling", "Solar Panel Usage"], correctAnswer: "Air Travel"),
    QuizQuestion(question: "What is 'biodiversity'?", options: ["Variety of life in an ecosystem", "Climate Change", "Deforestation", "Ocean Pollution"], correctAnswer: "Variety of life in an ecosystem"),
    QuizQuestion(question: "Which gas commonly contributes to urban smog?", options: ["Carbon Dioxide", "Ozone", "Methane", "Hydrogen"], correctAnswer: "Ozone"),
    QuizQuestion(question: "What practice can help reduce soil erosion?", options: ["Terrace Farming", "Deforestation", "Urbanization", "Chemical Fertilization"], correctAnswer: "Terrace Farming"),
    QuizQuestion(question: "Which is NOT a type of renewable energy?", options: ["Solar", "Coal", "Wind", "Hydropower"], correctAnswer: "Coal"),
    QuizQuestion(question: "The 'Three Rs' of waste management stand for:", options: ["Reduce, Reuse, Recycle", "Recover, Reuse, Recycle", "Reduce, Recover, Rebuild", "Rebuild, Reuse, Recycle"], correctAnswer: "Reduce, Reuse, Recycle"),
    QuizQuestion(question: "What is the main cause of ocean 'dead zones'?", options: ["Overfishing", "Nutrient Pollution", "Sunlight Depletion", "Increased Salinity"], correctAnswer: "Nutrient Pollution"),
    QuizQuestion(
        question: "What is the main cause of the greenhouse effect?",
        options: ["Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen"],
        correctAnswer: "Carbon Dioxide"
    ),
    QuizQuestion(
        question: "Which gas is most responsible for global warming?",
        options: ["Oxygen", "Carbon Monoxide", "Methane", "Nitrous Oxide"],
        correctAnswer: "Methane"
    ),
    QuizQuestion(
        question: "What percentage of the world's water is available as fresh water for drinking?",
        options: ["3%", "10%", "25%", "50%"],
        correctAnswer: "3%"
    ),
    QuizQuestion(question: "What is the term for farming practices that aim to produce food without harming the environment?", options: ["Industrial Farming", "Sustainable Agriculture", "Monoculture Farming", "Subsistence Farming"], correctAnswer: "Sustainable Agriculture"),
    QuizQuestion(question: "Which of the following is a renewable resource?", options: ["Coal", "Oil", "Wind", "Natural Gas"], correctAnswer: "Wind"),
    QuizQuestion(question: "What type of pollution is primarily caused by car exhaust and industrial emissions?", options: ["Water Pollution", "Soil Pollution", "Air Pollution", "Noise Pollution"], correctAnswer: "Air Pollution"),
    QuizQuestion(question: "Which term describes the variety of different types of life found on Earth?", options: ["Ecology", "Biodiversity", "Conservation", "Ecosystem"], correctAnswer: "Biodiversity"),
    QuizQuestion(question: "What does the term 'sustainable' mean in environmental science?", options: ["Exploiting Resources", "Using resources at a faster rate than they are replenished", "Maintaining ecological balance", "Focusing on short-term gains"], correctAnswer: "Maintaining ecological balance"),
    QuizQuestion(question: "Which practice reduces the need for pesticide use in agriculture?", options: ["Monoculture", "Organic Farming", "Overgrazing", "Deforestation"], correctAnswer: "Organic Farming"),
    QuizQuestion(question: "Which gas in the Earth's atmosphere is essential for protecting us from harmful UV radiation?", options: ["Carbon Dioxide", "Oxygen", "Ozone", "Nitrogen"], correctAnswer: "Ozone"),
    QuizQuestion(question: "What is the main purpose of a carbon footprint calculation?", options: ["To measure water usage", "To measure energy efficiency", "To quantify the greenhouse gases emitted", "To calculate the biodiversity"], correctAnswer: "To quantify the greenhouse gases emitted"),
    QuizQuestion(question: "What practice contributes to decreasing groundwater levels?", options: ["Rainwater Harvesting", "Overuse of Aquifers", "Afforestation", "Organic Farming"], correctAnswer: "Overuse of Aquifers"),
    QuizQuestion(question: "Which phenomenon leads to increased temperatures in urban areas compared to surrounding rural areas?", options: ["Greenhouse Effect", "Urban Heat Island", "Global Warming", "Deforestation"], correctAnswer: "Urban Heat Island"),
    QuizQuestion(question: "Which form of energy does not contribute to atmospheric carbon dioxide levels?", options: ["Fossil Fuels", "Solar Energy", "Coal", "Natural Gas"], correctAnswer: "Solar Energy"),
    QuizQuestion(question: "What is the primary cause of species extinction worldwide?", options: ["Habitat Loss", "Pollution", "Climate Change", "Overhunting"], correctAnswer: "Habitat Loss"),
    QuizQuestion(question: "Which activity significantly contributes to deforestation?", options: ["Recycling", "Urbanization", "Afforestation", "Logging"], correctAnswer: "Logging"),
    QuizQuestion(question: "What is the term for the increase in Earth's average surface temperature due to greenhouse gases?", options: ["Ozone Depletion", "Global Warming", "Urban Heat Island", "Acid Rain"], correctAnswer: "Global Warming"),
    QuizQuestion(question: "What is the main benefit of crop rotation in agriculture?", options: ["Increases use of chemical fertilizers", "Reduces soil fertility", "Prevents soil erosion", "Prevents pest build-up"], correctAnswer: "Prevents pest build-up"),
    // many more questions...
]

func questionsForToday() -> [QuizQuestion] {
    let dayOfYear = Calendar.current.ordinality(of: .day, in: .year, for: Date()) ?? 0
    let startIndex = (dayOfYear * 5) % (allQuizQuestions.count - 5)
    let endIndex = min(startIndex + 5, allQuizQuestions.count)
    return Array(allQuizQuestions[startIndex..<endIndex])
}

struct QuizView: View {

    let dailyQuestions: [QuizQuestion]
    @State private var currentQuestionIndex = 0
    @State private var correctAnswersCount = 0
    @State private var showResult = false

    var body: some View {
        VStack {
            if showResult {
                // Show results
                if correctAnswersCount>=5 {
                    Image("GOLD")
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: .infinity)
                        .shadow(color: .yellow,radius: 100)
                }
                else if correctAnswersCount>=3 {
                    Image("SILVER")
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: .infinity)
                        .shadow(color: .gray,radius: 100)
                }
                else {
                    Image("BRONZE")
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: .infinity)
                        .shadow(color: .brown,radius: 100)
                }
                
                Text("Score: \(correctAnswersCount * 20)")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding()
                // Add more result details and possibly a reward mechanism
                Text("You answered \(correctAnswersCount) out of 5 correctly!")
                // Add more result details and possibly a reward mechanism
                
            } else {
               
                Text("Daily Quiz")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding()
                
                // Show quiz question
                let question = dailyQuestions[currentQuestionIndex]
                Text(question.question)
                    .font(.title2)
                    .padding()
                ForEach(question.options, id: \.self) { option in
                    Button(action: {
                        // Handle answer
                        if option == question.correctAnswer {
                            correctAnswersCount += 1
                        }
                        if currentQuestionIndex < dailyQuestions.count - 1 {
                            currentQuestionIndex += 1
                        } else {
                            showResult = true
                        }
                    }) {
                        VStack{
                            Text(option)
                        }
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.green.opacity(0.3))
                        .cornerRadius(10)
                        .shadow(color: .green, radius: 5)
                    }
                    .padding(.horizontal)
                }
            }
        }
        .padding()
    }
}


