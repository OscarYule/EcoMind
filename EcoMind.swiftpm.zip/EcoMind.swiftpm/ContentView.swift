//
//  ContentView.swift
//  EcoMind
//
//  Created by Xavier Yan on 11/20/23.
//

import Foundation
import SwiftUI

struct ContentView: View {
    
    @State private var showQuiz = false
    @State private var quizCompleted = false
    @State private var correctAnswersCount = 0

    var body: some View {
        NavigationView {
            ScrollView {
                VStack {
                    Image("SIMPLE")
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: .infinity)
                        .shadow(color: .green,radius: 5)
                    
                    // Featured Eco-Tip Section
                    featuredEcoTipSection(){
                        //action
                    }
                    
                    // Menu Options
                    menuSection()
                }
                .padding(.horizontal)
                .sheet(isPresented: $showQuiz) {
                    QuizView(dailyQuestions: questionsForToday())
                }
            }
            .navigationBarTitle("EcoMind", displayMode: .automatic)
            .navigationBarItems(trailing: settingsButton())
        }
    }

    // Featured Eco-Tip Section
    func featuredEcoTipSection(action: @escaping () -> Void) -> some View {
        Button(action: action){
            VStack {
                Text("Daily Eco-Tip")
                    .font(.headline)
                    .foregroundColor(Color.black)
                    .padding([.leading, .bottom, .trailing])
                
                Text(ecoTipForToday())
                    .font(.subheadline)
                    .foregroundColor(Color.black)
                    
                
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(Color.green.opacity(0.3))
            .cornerRadius(10)
            .padding([.leading, .bottom, .trailing])
        }
    }

    //Eco-tips
    func ecoTipForToday() -> String {
        let dayOfYear = Calendar.current.ordinality(of: .day, in: .year, for: Date()) ?? 0
        return ecoTips[dayOfYear % ecoTips.count]
    }
    let ecoTips = [
        "Recycle your waste to save energy and reduce pollution.",
        "Turn off lights when not in use to conserve energy.",
        "Use reusable bags to reduce plastic waste.",
        "Reduce water usage by fixing leaky faucets and taking shorter showers. Every drop counts!",
        "Plant a tree or start a garden. Plants improve air quality and support local ecosystems.",
        "Switch to LED bulbs. They last longer and use less energy than traditional bulbs.",
        "Carpool, bike, or use public transportation to reduce carbon emissions from personal vehicles.",
        "Avoid single-use plastics. Opt for reusable bags, bottles, and containers whenever possible.",
        "Shop locally and choose organic products to support sustainable practices and reduce transportation emissions.",
        "Recycle and compost household waste to reduce landfill and nourish your garden.",
        "Reduce water usage by fixing leaky faucets and taking shorter showers. Every drop counts!",
        "Plant a tree or start a garden. Plants improve air quality and support local ecosystems.",
        "Switch to LED bulbs. They last longer and use less energy than traditional bulbs.",
        "Carpool, bike, or use public transportation to reduce carbon emissions from personal vehicles.",
        "Avoid single-use plastics. Opt for reusable bags, bottles, and containers whenever possible.",
        "Shop locally and choose organic products to support sustainable practices and reduce transportation emissions.",
        "Recycle and compost household waste to reduce landfill and nourish your garden.",
        "Conserve energy by unplugging electronics when not in use.",
        "Support renewable energy sources like solar or wind power.",
        "Use eco-friendly cleaning products to reduce chemical pollution.",
        "Reduce meat consumption to lower carbon footprint.",
        "Choose products with minimal packaging to reduce waste.",
        "Participate in local clean-up events to help your community.",
        "Educate others about the importance of environmental conservation.",
        "Donate to or volunteer for environmental conservation organizations.",
        "Use a refillable water bottle to reduce plastic waste.",
        "Opt for e-tickets and online receipts to save paper.",
        "Grow your own herbs and vegetables, even in small spaces.",
        "Invest in a reusable coffee cup for your daily brew.",
        "Conduct a home energy audit to find ways to improve efficiency.",
        "Choose sustainable fashion – buy less and choose well.",
        "Repair instead of replacing items to extend their life.",
        "Use public libraries and share books to reduce paper usage.",
        "Install a rain barrel to collect water for gardening.",
        "Take part in tree-planting initiatives in your area.",
        "Use natural light as much as possible to save electricity.",
        "Adopt a minimalist lifestyle to reduce consumption and waste.",
        "Choose products made from recycled materials.",
        "Reduce food waste by planning meals and storing food properly.",
        "Learn about local wildlife and how to protect it."
        // Add as many tips as you like
    ]

    
    // Menu Options Section
    func menuSection() -> some View {
        VStack(spacing: 20) {
            // Replace these with your actual menu items
            menuButton("Interactive Quizzes", "book.fill"){
                showQuiz = true
            }
            menuButton("Ecosystem Tours", "leaf.fill"){
                //action
            }
            menuButton("Impact Simulations", "wind"){
                //action
            }
            menuButton("Conservation Projects", "globe"){
                //action
            }
        }
        .padding()
    }

    // Generic Menu Button
    func menuButton(_ text: String, _ imageName: String, action: @escaping () -> Void) -> some View {
        Button(action: action){
            HStack {
                Image(systemName: imageName)
                    .foregroundColor(.green)
                Text(text)
                    .fontWeight(.semibold)
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(Color.white)
            .cornerRadius(10)
            .shadow(radius: 5)
        }
    }

    // Settings Button
    func settingsButton() -> some View {
        Button(action: {
            // Actions for settings button
        }) {
            Image(systemName: "gear")
                .foregroundColor(.gray)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
